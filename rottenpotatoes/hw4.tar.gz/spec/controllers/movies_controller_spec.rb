require 'spec_helper'

describe MoviesController do
	describe 'find movie with same director' do
		it 'should call the model method that finds the same directors' do
		#debugger
			Movie.should_receive(:find).with('Ridley Scott')
		end
		it 'should ' do
		end 
	end
end
